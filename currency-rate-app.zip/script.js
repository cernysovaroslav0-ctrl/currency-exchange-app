const API_URL = "https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange";

const elements = {
  currency: document.querySelector("#currency"),
  startDate: document.querySelector("#startDate"),
  endDate: document.querySelector("#endDate"),
  loadButton: document.querySelector("#loadButton"),
  downloadButton: document.querySelector("#downloadButton"),
  message: document.querySelector("#message"),
  firstRate: document.querySelector("#firstRate"),
  lastRate: document.querySelector("#lastRate"),
  changeRate: document.querySelector("#changeRate"),
  avgRate: document.querySelector("#avgRate"),
  rangeLabel: document.querySelector("#rangeLabel"),
  ratesTable: document.querySelector("#ratesTable"),
  chart: document.querySelector("#rateChart"),
};

let currentRates = [];

function toInputDate(date) {
  return date.toISOString().slice(0, 10);
}

function formatApiDate(date) {
  return date.toISOString().slice(0, 10).replaceAll("-", "");
}

function formatDisplayDate(date) {
  return new Intl.DateTimeFormat("uk-UA").format(date);
}

function parseInputDate(value) {
  const [year, month, day] = value.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day));
}

function eachDate(start, end) {
  const dates = [];
  const cursor = new Date(start);

  while (cursor <= end) {
    dates.push(new Date(cursor));
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }

  return dates;
}

function setMessage(text, isError = false) {
  elements.message.textContent = text;
  elements.message.classList.toggle("error", isError);
}

async function fetchRate(currency, date) {
  const url = `${API_URL}?valcode=${currency}&date=${formatApiDate(date)}&json`;
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error("Не вдалося отримати дані від НБУ.");
  }

  const [rate] = await response.json();

  if (!rate) {
    return null;
  }

  return {
    date: formatDisplayDate(date),
    rawDate: toInputDate(date),
    currency: rate.cc,
    name: rate.txt,
    value: Number(rate.rate),
  };
}

async function loadRates() {
  const currency = elements.currency.value;
  const start = parseInputDate(elements.startDate.value);
  const end = parseInputDate(elements.endDate.value);

  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    setMessage("Оберіть початкову та кінцеву дату.", true);
    return;
  }

  if (start > end) {
    setMessage("Початкова дата має бути раніше або дорівнювати кінцевій.", true);
    return;
  }

  const dates = eachDate(start, end);

  if (dates.length > 31) {
    setMessage("Оберіть діапазон до 31 дня, щоб запит не був занадто довгим.", true);
    return;
  }

  elements.loadButton.disabled = true;
  setMessage("Завантажую курси валют...");

  try {
    const rates = (await Promise.all(dates.map((date) => fetchRate(currency, date)))).filter(Boolean);
    currentRates = rates;

    if (!rates.length) {
      setMessage("За вибраний період даних не знайдено.", true);
      renderTable([]);
      renderSummary([]);
      drawChart([]);
      return;
    }

    renderSummary(rates);
    renderTable(rates);
    drawChart(rates);
    setMessage(`Завантажено ${rates.length} записів.`);
  } catch (error) {
    setMessage(error.message, true);
  } finally {
    elements.loadButton.disabled = false;
  }
}

function renderSummary(rates) {
  if (!rates.length) {
    elements.firstRate.textContent = "-";
    elements.lastRate.textContent = "-";
    elements.changeRate.textContent = "-";
    elements.avgRate.textContent = "-";
    elements.rangeLabel.textContent = "";
    return;
  }

  const first = rates[0].value;
  const last = rates.at(-1).value;
  const change = last - first;
  const average = rates.reduce((sum, item) => sum + item.value, 0) / rates.length;

  elements.firstRate.textContent = first.toFixed(4);
  elements.lastRate.textContent = last.toFixed(4);
  elements.avgRate.textContent = average.toFixed(4);
  elements.changeRate.textContent = `${change >= 0 ? "+" : ""}${change.toFixed(4)}`;
  elements.changeRate.className = change >= 0 ? "positive" : "negative";
  elements.rangeLabel.textContent = `${rates[0].date} - ${rates.at(-1).date}`;
}

function renderTable(rates) {
  if (!rates.length) {
    elements.ratesTable.innerHTML = '<tr><td colspan="4">Немає даних для показу.</td></tr>';
    return;
  }

  elements.ratesTable.innerHTML = rates
    .map(
      (rate) => `
        <tr>
          <td>${rate.date}</td>
          <td>${rate.currency}</td>
          <td>${rate.name}</td>
          <td>${rate.value.toFixed(4)}</td>
        </tr>
      `
    )
    .join("");
}

function drawChart(rates) {
  const canvas = elements.chart;
  const ctx = canvas.getContext("2d");
  const width = canvas.width;
  const height = canvas.height;
  const padding = { top: 34, right: 34, bottom: 64, left: 78 };

  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "#fbfdff";
  ctx.fillRect(0, 0, width, height);

  if (!rates.length) {
    ctx.fillStyle = "#667085";
    ctx.font = "24px Segoe UI, Arial";
    ctx.fillText("Оберіть параметри та завантажте дані", 290, 210);
    return;
  }

  const values = rates.map((rate) => rate.value);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const spread = max - min || 1;
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  ctx.strokeStyle = "#d9e2ef";
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let i = 0; i <= 4; i += 1) {
    const y = padding.top + (chartHeight / 4) * i;
    ctx.moveTo(padding.left, y);
    ctx.lineTo(width - padding.right, y);
  }
  ctx.stroke();

  ctx.fillStyle = "#667085";
  ctx.font = "16px Segoe UI, Arial";
  ctx.textAlign = "right";
  for (let i = 0; i <= 4; i += 1) {
    const value = max - (spread / 4) * i;
    const y = padding.top + (chartHeight / 4) * i + 5;
    ctx.fillText(value.toFixed(4), padding.left - 12, y);
  }

  const points = rates.map((rate, index) => {
    const x = padding.left + (chartWidth / Math.max(rates.length - 1, 1)) * index;
    const y = padding.top + chartHeight - ((rate.value - min) / spread) * chartHeight;
    return { x, y, rate };
  });

  ctx.strokeStyle = "#0b6bcb";
  ctx.lineWidth = 4;
  ctx.beginPath();
  points.forEach((point, index) => {
    if (index === 0) {
      ctx.moveTo(point.x, point.y);
    } else {
      ctx.lineTo(point.x, point.y);
    }
  });
  ctx.stroke();

  points.forEach((point) => {
    ctx.fillStyle = "#ffffff";
    ctx.strokeStyle = "#0b6bcb";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(point.x, point.y, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  });

  ctx.fillStyle = "#14213d";
  ctx.font = "14px Segoe UI, Arial";
  ctx.textAlign = "center";
  const labelStep = Math.ceil(points.length / 8);
  points.forEach((point, index) => {
    if (index % labelStep === 0 || index === points.length - 1) {
      ctx.fillText(point.rate.date.slice(0, 5), point.x, height - 26);
    }
  });
}

function downloadCsv() {
  if (!currentRates.length) {
    setMessage("Спочатку завантажте дані для таблиці.", true);
    return;
  }

  const header = "date,currency,name,rate";
  const rows = currentRates.map((rate) =>
    [rate.rawDate, rate.currency, `"${rate.name.replaceAll('"', '""')}"`, rate.value.toFixed(4)].join(",")
  );
  const blob = new Blob([[header, ...rows].join("\n")], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `rates-${elements.currency.value}-${elements.startDate.value}-${elements.endDate.value}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

function setDefaultDates() {
  const today = new Date();
  const end = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()));
  const start = new Date(end);
  start.setUTCDate(start.getUTCDate() - 6);

  elements.startDate.value = toInputDate(start);
  elements.endDate.value = toInputDate(end);
}

elements.loadButton.addEventListener("click", loadRates);
elements.downloadButton.addEventListener("click", downloadCsv);

setDefaultDates();
drawChart([]);
