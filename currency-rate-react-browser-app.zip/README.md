# Курс валют НБУ на React без npm

Це React-версія застосунку, яку можна відкрити напряму через `index.html`.

## Як запустити

Відкрийте файл `index.html` у браузері.

Для роботи потрібен інтернет, тому що React підключається через CDN:

```text
https://unpkg.com/react
https://unpkg.com/react-dom
```

## Можливості

- вибір валюти;
- вибір діапазону дат;
- завантаження даних з API НБУ;
- підсумкові картки;
- графік;
- таблиця;
- експорт CSV.

## Джерело даних

```text
https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange
```
